# Pirat Theme Kit

Requer Node.js 22 ou superior. Sem instalação de dependências.

```sh
node pirat.mjs init minha-loja retail
node pirat.mjs validate minha-loja
node pirat.mjs build minha-loja
```

Edite minha-loja/theme.json com sua IA. Consulte THEME-RULES.md e theme.schema.json. Importe minha-loja/dist/theme.pirat.json no editor em Modelos → Importar tema. A CLI não publica nem autentica. Modelos: minimal, retail e marketplace.
